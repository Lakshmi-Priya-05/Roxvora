import React, {useEffect, useMemo, useState} from "react";
import {Routes, Route, Link, useNavigate, useParams, Navigate, useLocation} from "react-router-dom";
import {Search, ShoppingBag, Heart, User, Menu, X, ChevronRight, Star, Trash2, Plus, Minus, Package, LayoutDashboard, LogOut, Pencil, Truck, ShieldCheck, ArrowRight, SlidersHorizontal} from "lucide-react";
import api from "./api";

const products = [
  {id:"p1",name:"Minimal Chrono Watch",category:"Watches",price:3499,oldPrice:4999,rating:4.8,image:"https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=800&q=80",badge:"BEST SELLER"},
  {id:"p2",name:"Urban Leather Sneakers",category:"Footwear",price:2899,oldPrice:3999,rating:4.7,image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80",badge:"NEW"},
  {id:"p3",name:"Essential Black Backpack",category:"Bags",price:2199,oldPrice:2999,rating:4.6,image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80",badge:"TRENDING"},
  {id:"p4",name:"Classic Premium Shirt",category:"Men's Fashion",price:1799,oldPrice:2399,rating:4.9,image:"https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&w=800&q=80"},
  {id:"p5",name:"Aero Smart Watch",category:"Watches",price:4299,oldPrice:5999,rating:4.8,image:"https://images.unsplash.com/photo-1544117519-31a4b719223d?auto=format&fit=crop&w=800&q=80",badge:"SALE"},
  {id:"p6",name:"Noir Sunglasses",category:"Sunglasses",price:1299,oldPrice:1899,rating:4.5,image:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80"},
  {id:"p7",name:"Signature Leather Belt",category:"Accessories",price:899,oldPrice:1299,rating:4.7,image:"https://images.unsplash.com/photo-1624222247344-550fb60583dc?auto=format&fit=crop&w=800&q=80"},
  {id:"p8",name:"Midnight Eau de Parfum",category:"Perfume",price:1599,oldPrice:2199,rating:4.6,image:"https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=800&q=80"}
];

const categories = [
  ["Men's Fashion","https://images.unsplash.com/photo-1617127365659-c47fa864d8bc?auto=format&fit=crop&w=700&q=80"],
  ["Footwear","https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=700&q=80"],
  ["Watches","https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=700&q=80"],
  ["Bags","https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=700&q=80"],
  ["Sunglasses","https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=700&q=80"],
  ["Accessories","https://images.unsplash.com/photo-1523779917675-b6ed3a42a561?auto=format&fit=crop&w=700&q=80"]
];

function useLocalStorage(key, initial){
  const [value,setValue] = useState(()=>{try{return JSON.parse(localStorage.getItem(key)) ?? initial}catch{return initial}});
  useEffect(()=>localStorage.setItem(key,JSON.stringify(value)),[key,value]);
  return [value,setValue];
}

function Header({cartCount,wishlistCount,user,onLogout}){
  const [open,setOpen]=useState(false); const [q,setQ]=useState(""); const nav=useNavigate();
  const submit=e=>{e.preventDefault(); if(q.trim()) nav("/shop?search="+encodeURIComponent(q.trim()));};
  return <header className="header">
    <div className="topbar">FREE SHIPPING ON ORDERS ABOVE ₹1,999 <span>•</span> EASY 7-DAY RETURNS</div>
    <div className="nav">
      <button className="icon-btn mobile-only" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
      <Link to="/" className="logo">ROXVORA<span>®</span><small>OWN THE LOOK</small></Link>
      <nav className={open?"navlinks open":"navlinks"}>
        {["Shop","Men","Footwear","Watches","Bags","Accessories"].map(x=><Link key={x} to={"/shop?category="+encodeURIComponent(x)} onClick={()=>setOpen(false)}>{x}</Link>)}
        <Link to="/offers" onClick={()=>setOpen(false)}>Offers</Link>
      </nav>
      <div className="nav-actions">
        <form onSubmit={submit} className="search"><Search size={17}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search products..."/></form>
        <Link className="nav-icon" to="/wishlist"><Heart/><b>{wishlistCount}</b></Link>
        <Link className="nav-icon" to="/cart"><ShoppingBag/><b>{cartCount}</b></Link>
        {user?<button className="nav-icon" onClick={onLogout}><LogOut/></button>:<Link className="nav-icon" to="/login"><User/></Link>}
      </div>
    </div>
  </header>
}

function Footer(){return <footer><div className="footer-main">
  <div><div className="logo footer-logo">ROXVORA<small>OWN THE LOOK</small></div><p>Modern fashion and lifestyle essentials for people who own their look.</p></div>
  <div><h4>SHOP</h4><Link to="/shop">All Products</Link><Link to="/shop?category=Men's Fashion">Men</Link><Link to="/shop?category=Footwear">Footwear</Link><Link to="/shop?category=Watches">Watches</Link></div>
  <div><h4>HELP</h4><Link to="/contact">Contact</Link><Link to="/account">My Account</Link><Link to="/orders">Orders</Link><span>Shipping & Returns</span></div>
  <div><h4>NEWSLETTER</h4><p>Get first access to drops and offers.</p><div className="newsletter"><input placeholder="Your email"/><button>JOIN</button></div></div>
</div><div className="footer-bottom">© 2026 ROXVORA. All rights reserved. <span>Privacy · Terms</span></div></footer>}

function ProductCard({p,onCart,onWish,wished}){
 return <div className="product-card">
   <Link to={"/product/"+p.id} className="product-img"><img src={p.image}/>{p.badge&&<span>{p.badge}</span>}<button className={wished?"wish active":"wish"} onClick={e=>{e.preventDefault();onWish(p)}}><Heart fill={wished?"currentColor":"none"}/></button></Link>
   <div className="product-info"><small>{p.category}</small><Link to={"/product/"+p.id} className="product-name">{p.name}</Link><div className="rating"><Star fill="currentColor"/> {p.rating}</div><div className="price">₹{p.price.toLocaleString()} <del>₹{p.oldPrice.toLocaleString()}</del></div><button className="add-btn" onClick={()=>onCart(p)}>ADD TO CART</button></div>
 </div>
}

function Home({onCart,onWish,wishlist}){
 return <><section className="hero">
   <div className="hero-card hero-main"><div><small>NEW SEASON</small><h1>Best Fashion<br/><em>For Every You</em></h1><p>Discover refined essentials made for your everyday confidence.</p><Link to="/shop" className="dark-btn">SHOP NOW <ArrowRight size={16}/></Link></div><img src="https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=1200&q=85"/></div>
   <div className="hero-side"><div className="mini-card fashion"><span>UP TO 50% OFF</span><h2>Stylish Looks<br/>For Any Season</h2><Link to="/shop">Shop Now</Link><img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=700&q=80"/></div><div className="mini-row"><div><b>UP TO 30% OFF</b><h3>Men's Fashion</h3><Link to="/shop">Shop Now</Link></div><img src="https://images.unsplash.com/photo-1610652492500-ded49ceeb378?auto=format&fit=crop&w=500&q=80"/></div></div>
 </section>
 <section className="section dark-section"><div className="section-head light"><div><small>CURATED FOR YOU</small><h2>Weekly Best Deals</h2></div><Link to="/shop">View All <ChevronRight size={16}/></Link></div><div className="product-grid">{products.slice(0,5).map(p=><ProductCard key={p.id} p={p} onCart={onCart} onWish={onWish} wished={wishlist.some(x=>x.id===p.id)}/>)}</div></section>
 <section className="section"><div className="section-head"><div><small>EXPLORE</small><h2>Shop by Category</h2></div><Link to="/shop">All Categories <ChevronRight size={16}/></Link></div><div className="category-grid">{categories.map(([n,img])=><Link to={"/shop?category="+encodeURIComponent(n)} className="category-card" key={n}><img src={img}/><div><h3>{n}</h3><span>Explore <ArrowRight size={14}/></span></div></Link>)}</div></section>
 <section className="promo"><div><small>SMART STYLE</small><h2>Technology meets<br/><em>your lifestyle.</em></h2><p>Explore smartwatches and modern accessories.</p><Link to="/shop?category=Watches" className="light-btn">EXPLORE WATCHES</Link></div><img src="https://images.unsplash.com/photo-1544117519-31a4b719223d?auto=format&fit=crop&w=900&q=80"/></section>
 <section className="section"><div className="section-head"><div><small>JUST DROPPED</small><h2>New Arrivals</h2></div><Link to="/shop">View All <ChevronRight size={16}/></Link></div><div className="product-grid">{products.slice(3).map(p=><ProductCard key={p.id} p={p} onCart={onCart} onWish={onWish} wished={wishlist.some(x=>x.id===p.id)}/>)}</div></section>
 </>;
}

function Shop({onCart,onWish,wishlist}){
 const loc=useLocation(); const params=new URLSearchParams(loc.search); const initial=params.get("category")||"All"; const [category,setCategory]=useState(initial); const [sort,setSort]=useState("featured"); const [filter,setFilter]=useState(false);
 const q=(params.get("search")||"").toLowerCase();
 let list=products.filter(p=>(category==="All"||p.category===category)&&(p.name.toLowerCase().includes(q)||p.category.toLowerCase().includes(q)));
 if(sort==="low") list.sort((a,b)=>a.price-b.price); if(sort==="high") list.sort((a,b)=>b.price-a.price);
 return <section className="shop-page"><div className="shop-title"><small>COLLECTION</small><h1>{q?`Search: ${q}`:category==="All"?"All Products":category}</h1><p>Premium pieces selected for the ROXVORA lifestyle.</p></div>
 <div className="shop-toolbar"><button className="filter-mobile" onClick={()=>setFilter(!filter)}><SlidersHorizontal/> Filters</button><div className="category-pills">{["All","Men's Fashion","Footwear","Watches","Bags","Sunglasses","Accessories","Perfume"].map(c=><button className={category===c?"active":""} onClick={()=>setCategory(c)} key={c}>{c}</button>)}</div><select value={sort} onChange={e=>setSort(e.target.value)}><option value="featured">Featured</option><option value="low">Price: Low to High</option><option value="high">Price: High to Low</option></select></div>
 <div className={filter?"filter-panel open":"filter-panel"}><h3>Filters</h3><label><input type="checkbox"/> In stock</label><label><input type="checkbox"/> New arrivals</label><label><input type="checkbox"/> On sale</label></div>
 <div className="product-grid shop-grid">{list.map(p=><ProductCard key={p.id} p={p} onCart={onCart} onWish={onWish} wished={wishlist.some(x=>x.id===p.id)}/>)}</div>
 {list.length===0&&<div className="empty"><Package/><h3>No products found</h3><p>Try another category or search term.</p></div>}</section>
}

function ProductPage({onCart,onWish,wishlist}){
 const {id}=useParams(); const p=products.find(x=>x.id===id)||products[0]; const [qty,setQty]=useState(1);
 return <section className="product-page"><div className="crumb"><Link to="/">Home</Link> / <Link to="/shop">Shop</Link> / {p.name}</div><div className="product-detail"><div className="gallery"><img src={p.image}/><div className="thumb"><img src={p.image}/><img src={p.image}/><img src={p.image}/></div></div><div className="detail-info"><small>{p.category}</small><h1>{p.name}</h1><div className="rating"><Star fill="currentColor"/> {p.rating} · 28 Reviews</div><div className="big-price">₹{p.price.toLocaleString()} <del>₹{p.oldPrice.toLocaleString()}</del></div><p>Premium ROXVORA design crafted for comfort, durability and everyday style. Product specifications and final stock can be managed from the admin panel.</p><hr/><label>SELECT SIZE</label><div className="sizes"><button>S</button><button>M</button><button>L</button><button>XL</button></div><label>QUANTITY</label><div className="qty"><button onClick={()=>setQty(Math.max(1,qty-1))}><Minus/></button><b>{qty}</b><button onClick={()=>setQty(qty+1)}><Plus/></button></div><button className="buy" onClick={()=>{for(let i=0;i<qty;i++)onCart(p)}}>ADD TO CART — ₹{(p.price*qty).toLocaleString()}</button><button className="outline" onClick={()=>onWish(p)}>{wishlist.some(x=>x.id===p.id)?"♥ IN WISHLIST":"♡ ADD TO WISHLIST"}</button><div className="trust"><span><ShieldCheck/> Secure checkout</span><span><Truck/> Fast delivery</span></div></div></div></section>
}

function Cart({cart,setCart}){
 const total=cart.reduce((s,x)=>s+x.price*x.qty,0); const shipping=total>=1999||total===0?0:99;
 const update=(id,d)=>setCart(c=>c.map(x=>x.id===id?{...x,qty:Math.max(1,x.qty+d)}:x)); const remove=id=>setCart(c=>c.filter(x=>x.id!==id));
 return <section className="page"><div className="shop-title"><small>YOUR BAG</small><h1>Shopping Cart</h1></div>{cart.length===0?<div className="empty"><ShoppingBag/><h3>Your cart is empty</h3><Link className="dark-btn" to="/shop">CONTINUE SHOPPING</Link></div>:<div className="cart-layout"><div>{cart.map(x=><div className="cart-item" key={x.id}><img src={x.image}/><div><small>{x.category}</small><h3>{x.name}</h3><b>₹{x.price.toLocaleString()}</b><div className="qty"><button onClick={()=>update(x.id,-1)}><Minus/></button><b>{x.qty}</b><button onClick={()=>update(x.id,1)}><Plus/></button></div></div><button className="delete" onClick={()=>remove(x.id)}><Trash2/></button></div>)}</div><aside className="summary"><h2>Order Summary</h2><p><span>Subtotal</span><b>₹{total.toLocaleString()}</b></p><p><span>Shipping</span><b>{shipping?"₹"+shipping:"FREE"}</b></p><hr/><p className="total"><span>Total</span><b>₹{(total+shipping).toLocaleString()}</b></p><Link className="buy" to="/checkout">PROCEED TO CHECKOUT</Link></aside></div>}</section>
}

function Wishlist({wishlist,onCart,onWish}){return <section className="page"><div className="shop-title"><small>SAVED FOR LATER</small><h1>Wishlist</h1></div>{wishlist.length?<div className="product-grid">{wishlist.map(p=><ProductCard key={p.id} p={p} onCart={onCart} onWish={onWish} wished/>)}</div>:<div className="empty"><Heart/><h3>Your wishlist is empty</h3><Link className="dark-btn" to="/shop">EXPLORE PRODUCTS</Link></div>}</section>}

function Checkout({cart,clearCart}){
 const [done,setDone]=useState(false); const total=cart.reduce((s,x)=>s+x.price*x.qty,0)+(cart.reduce((s,x)=>s+x.price*x.qty,0)>=1999?0:99);
 if(done)return <section className="empty success"><Package/><h1>Order Confirmed!</h1><p>Thank you for shopping with ROXVORA. Your order has been placed.</p><Link to="/" className="dark-btn">BACK TO HOME</Link></section>;
 return <section className="checkout"><div><div className="shop-title left"><small>CHECKOUT</small><h1>Complete your order</h1></div><div className="form-card"><h2>Customer Information</h2><div className="form-grid"><input placeholder="First name"/><input placeholder="Last name"/><input placeholder="Email address"/><input placeholder="Phone number"/></div><h2>Delivery Address</h2><textarea placeholder="Full address"></textarea><div className="form-grid"><input placeholder="City"/><input placeholder="State"/><input placeholder="Pincode"/></div><h2>Payment</h2><div className="payment-options"><label><input type="radio" name="p" defaultChecked/> Cash on Delivery</label><label><input type="radio" name="p"/> Online Payment (mock)</label></div><button className="buy" onClick={()=>{setDone(true);clearCart()}}>PLACE ORDER — ₹{total.toLocaleString()}</button></div></div><aside className="summary"><h2>Your Items</h2>{cart.map(x=><p key={x.id}><span>{x.name} × {x.qty}</span><b>₹{(x.price*x.qty).toLocaleString()}</b></p>)}</aside></section>
}

function Login({setUser}){
 const [mode,setMode]=useState("login"); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const nav=useNavigate();
 const submit=async e=>{e.preventDefault(); try{const r=mode==="login"?await api.post("/auth/login",{email,password}):await api.post("/auth/register",{email,password,name:email.split("@")[0]}); localStorage.setItem("token",r.data.token);setUser(r.data.user);nav("/");}catch(err){alert(err.response?.data?.detail||"Unable to continue. Backend must be running.")}};
 return <section className="auth"><div className="auth-card"><div className="logo">ROXVORA<small>OWN THE LOOK</small></div><h1>{mode==="login"?"Welcome back":"Create account"}</h1><p>{mode==="login"?"Sign in to continue shopping.":"Join ROXVORA for faster checkout and order tracking."}</p><form onSubmit={submit}><input type="email" placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="buy">{mode==="login"?"SIGN IN":"CREATE ACCOUNT"}</button></form><button className="switch" onClick={()=>setMode(mode==="login"?"register":"login")}>{mode==="login"?"New to ROXVORA? Create an account":"Already have an account? Sign in"}</button></div></section>
}

function Admin({user}){
 const [data,setData]=useState({products:products,orders:12,customers:86,revenue:284560});
 if(!user?.role || user.role!=="admin") return <Navigate to="/" replace/>;
 return <section className="admin"><aside className="admin-side"><div className="logo">ROXVORA<small>ADMIN</small></div><Link className="active" to="/admin"><LayoutDashboard/> Dashboard</Link><Link to="/shop"><Package/> Store</Link><Link to="/admin/products"><Pencil/> Products</Link><Link to="/admin/orders"><Truck/> Orders</Link><Link to="/admin/customers"><User/> Customers</Link></aside><main className="admin-main"><div className="admin-head"><div><small>ADMIN PANEL</small><h1>Dashboard</h1></div><Link to="/">View Store ↗</Link></div><div className="stats"><div><small>REVENUE</small><h2>₹{data.revenue.toLocaleString()}</h2><span>+12.8% this month</span></div><div><small>ORDERS</small><h2>{data.orders}</h2><span>8 pending</span></div><div><small>CUSTOMERS</small><h2>{data.customers}</h2><span>+14 this week</span></div><div><small>PRODUCTS</small><h2>{data.products.length}</h2><span>3 low stock</span></div></div><div className="admin-grid"><div className="admin-panel"><h2>Recent Orders</h2>{["#RXV-1082"," #RXV-1081","#RXV-1080","#RXV-1079"].map((o,i)=><div className="order-row" key={o}><b>{o}</b><span>{["Delivered","Processing","Shipped","Pending"][i]}</span><strong>₹{[4898,3299,2199,1599][i]}</strong></div>)}</div><div className="admin-panel"><h2>Low Stock</h2>{products.slice(0,4).map(p=><div className="order-row" key={p.id}><span>{p.name}</span><strong>{[3,5,2,4][products.indexOf(p)]} left</strong></div>)}</div></div></main></section>
}

function Contact(){return <section className="page contact"><div className="shop-title"><small>SUPPORT</small><h1>Let's talk.</h1><p>Questions about products, orders or collaborations?</p></div><div className="form-card"><div className="form-grid"><input placeholder="Your name"/><input placeholder="Email address"/></div><input placeholder="Subject"/><textarea placeholder="How can we help?"></textarea><button className="buy">SEND MESSAGE</button></div></section>}

function App(){
 const [cart,setCart]=useLocalStorage("roxvora_cart",[]); const [wishlist,setWishlist]=useLocalStorage("roxvora_wishlist",[]); const [user,setUser]=useState(()=>{try{return JSON.parse(localStorage.getItem("roxvora_user"))}catch{return null}});
 useEffect(()=>{if(user)localStorage.setItem("roxvora_user",JSON.stringify(user));else localStorage.removeItem("roxvora_user")},[user]);
 const onCart=p=>setCart(c=>{const f=c.find(x=>x.id===p.id); return f?c.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x):[...c,{...p,qty:1}]});
 const onWish=p=>setWishlist(c=>c.some(x=>x.id===p.id)?c.filter(x=>x.id!==p.id):[...c,p]);
 const logout=()=>{localStorage.removeItem("token");setUser(null)};
 return <><Header cartCount={cart.reduce((s,x)=>s+x.qty,0)} wishlistCount={wishlist.length} user={user} onLogout={logout}/><Routes>
   <Route path="/" element={<Home onCart={onCart} onWish={onWish} wishlist={wishlist}/>}/>
   <Route path="/shop" element={<Shop onCart={onCart} onWish={onWish} wishlist={wishlist}/>}/>
   <Route path="/product/:id" element={<ProductPage onCart={onCart} onWish={onWish} wishlist={wishlist}/>}/>
   <Route path="/cart" element={<Cart cart={cart} setCart={setCart}/>}/>
   <Route path="/wishlist" element={<Wishlist wishlist={wishlist} onCart={onCart} onWish={onWish}/>}/>
   <Route path="/checkout" element={<Checkout cart={cart} clearCart={()=>setCart([])}/>}/>
   <Route path="/login" element={<Login setUser={setUser}/>}/>
   <Route path="/contact" element={<Contact/>}/>
   <Route path="/admin" element={<Admin user={user}/>}/>
   <Route path="*" element={<div className="empty"><h1>404</h1><Link to="/" className="dark-btn">GO HOME</Link></div>}/>
 </Routes><Footer/></>
}
export default App;
